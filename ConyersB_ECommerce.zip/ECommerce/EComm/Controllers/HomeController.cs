﻿using EComm.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EComm.Controllers
{
    public class HomeController : Controller
    {
        public VertexProductsEntities3 Products { get; set; } = new VertexProductsEntities3();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Catalog()
        {
            return View("~/Views/Home/Catalog.cshtml", Products.ProductDBs.ToList());
        }

        public ActionResult Search(Search search)
        {
            return View("~/Views/Home/Catalog.cshtml", Products.ProductDBs.Where(prod => prod.Name.Contains(search.Value)).ToList());
        }

        public ActionResult Product(Guid id)
        {
            return View("_Product", Products.ProductDBs.Where(p => p.ID == id).First());

        }

        public ActionResult Cart(string cartID)
        {
            return View("~/Views/Home/_Cart.cshtml", HttpContext.User.Identity.Name);
        }

        public ActionResult _Cart()
        {
            return View("~/Views/Home/_Cart.cshtml", GetUserCart());
        }

        public List<CartProduct> GetProductsInCart(Cart cart)
        {
            return new VertexProductsEntities2().CartProducts.Where(prod => prod.ShopCartID == cart.CartID).ToList();
        }

        public Cart GetUserCart()
        {
            if (User.Identity.IsAuthenticated)
            {
                AccountController accControl = new AccountController();
                ApplicationUser user = accControl.GetUser(User.Identity.Name);
                Guid userID = Guid.Parse(user.Id);
                List<Cart> userCarts = new VertexProductsEntities2().Carts.Where(cart => cart.UserID == userID).ToList();
                VertexProductsEntities2 carts = new VertexProductsEntities2();
                if (userCarts.Count <= 0)
                {
                    Cart newCart = new Cart() { UserID = Guid.Parse(user.Id), CartID = Guid.NewGuid() };
                    userCarts.Add(newCart);
                    carts.Carts.Add(newCart);
                    carts.Entry(newCart).State = System.Data.Entity.EntityState.Added;
                }

                carts.SaveChanges();
                return userCarts[0];
            }

            else
            {
                return null;
            }

        }

        public decimal Total(List<CartProduct> cart)
        {
            decimal? totalAmount = 0;
            foreach(CartProduct c in cart)
            {
                totalAmount += Products.ProductDBs.Where(prod => prod.ID == c.ProductID).First().Price * c.count;
            }

            return (decimal)totalAmount;
        }

        public ActionResult AddToCart(string productID)
        {
            Guid prodID = Guid.Parse(productID);
            Cart userCart = GetUserCart();

            VertexProductsEntities2 Carts = new VertexProductsEntities2();

            List<CartProduct> matchingProducts = Carts.CartProducts.Where(cartProd => cartProd.ProductID == prodID && cartProd.ShopCartID == userCart.CartID).ToList();

            if(matchingProducts.Count==0)
            {
                CartProduct newProduct = new CartProduct()
                {
                    ProductID = prodID,
                    ShopCartID = userCart.CartID,
                    count = 1
                };
                Carts.CartProducts.Add(newProduct);
                Carts.Entry(newProduct).State = System.Data.Entity.EntityState.Added;
            }
            else
            {
                matchingProducts[0].count++;
                Carts.Entry(matchingProducts[0]).State = System.Data.Entity.EntityState.Modified;
            }

            Carts.SaveChanges();
            return Catalog();
        }

        public void RemoveFromCart(Guid productID)
        {
            Cart userCart = GetUserCart();

            VertexProductsEntities2 Carts = new VertexProductsEntities2();

            List<CartProduct> matchingProducts = Carts.CartProducts.Where(cartProd => cartProd.ProductID == productID && cartProd.ShopCartID == userCart.CartID).ToList();

            if (matchingProducts.Count != 0)
            {
                Carts.CartProducts.Remove(matchingProducts[0]);
                Carts.Entry(matchingProducts[0]).State = System.Data.Entity.EntityState.Deleted;
            }

            Carts.SaveChanges();
        }

        public ActionResult ChangeAmount(CartProduct prodMod)
        {
            Cart userCart = GetUserCart();
            VertexProductsEntities2 Carts = new VertexProductsEntities2();
            List<CartProduct> matchingProducts = Carts.CartProducts.Where(cartProd => cartProd.ProductID == prodMod.ProductID && cartProd.ShopCartID == userCart.CartID).ToList();

            if (prodMod.count<=0)
            {
                RemoveFromCart(prodMod.ProductID);
            }
            else
            {
                matchingProducts[0].count = prodMod.count;
                Carts.Entry(matchingProducts[0]).State = System.Data.Entity.EntityState.Modified;
                Carts.SaveChanges();
            }

            return View("~/Views/Home/_Cart.cshtml", GetUserCart());
        }

        public ActionResult Checkout()
        {
            AccountController accControl = new AccountController();
            ApplicationUser user = accControl.GetUser(User.Identity.Name);
            Guid userID = Guid.Parse(user.Id);
            VertexProductsEntities2 carts = new VertexProductsEntities2();

            carts.Carts.Remove(carts.Carts.Where(c => c.UserID == userID).First());
            carts.Carts.Add(new Cart() { UserID = userID, CartID = Guid.NewGuid() });
            return View("~/Views/Home/_Checkout.cshtml", Total(GetProductsInCart(GetUserCart())));
        }
    }
}