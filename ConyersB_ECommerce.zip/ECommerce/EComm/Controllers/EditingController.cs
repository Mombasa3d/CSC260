﻿using EComm.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EComm.Controllers
{
    public class EditingController : Controller
    {
         public VertexProductsEntities3 Products { get; set; } = new VertexProductsEntities3();
        // GET: Editing
        public ActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Edit(Guid id)
        {
            return View("_Edit", Products.ProductDBs.Where(v => v.ID == id).Single());
        }

        [Authorize(Roles = "Admin")]
        public ActionResult AddNewModel()
        {
            return View("_Edit", new ProductDB());
        }

        [Authorize(Roles = "Admin")]
        public ActionResult RemoveItem(Guid id)
        {
            if(ModelState.IsValid)
            {
                var temp = Products.ProductDBs.Where(w => w.ID == id).Single();
                Products.Entry(temp).State = System.Data.Entity.EntityState.Deleted;
                Products.ProductDBs.Remove(temp);
            }
            Products.SaveChanges();
            return RedirectToAction("Catalog", "Home");
        }

        [Authorize(Roles = "Admin")]
        public ActionResult EFChanges(ProductDB model)
        {
            if(ModelState.IsValid)
            {
                if(Products.ProductDBs.Any(i => i.ID == model.ID) )
                {
                    ProductDB tempItem = Products.ProductDBs.Where(w => w.ID == model.ID).Single(); 
                    tempItem.ID = model.ID;
                    tempItem.Name = model.Name;
                    tempItem.Price = model.Price;
                    tempItem.Descriptor = model.Descriptor;
                    tempItem.Features = model.Features;
                    tempItem.ImageURL = model.ImageURL;
                    Products.Entry(tempItem).State = System.Data.Entity.EntityState.Modified;
                }
                else
                {
                    Guid id = Guid.NewGuid();
                    model.ID = id;
                    Products.ProductDBs.Add(model);
                    Products.Entry(model).State = System.Data.Entity.EntityState.Added;
                }

                Products.SaveChanges();
                return RedirectToAction("Catalog", "Home");
            }
            else
            {
                return View("_Edit", model);
            }
        }
    }
}