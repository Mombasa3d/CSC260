﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace EComm
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "AddToCart",
                url: "Home/AddToCart/{productID}",
                defaults: new {controller = "Home", action ="AddToCart", id = UrlParameter.Optional}
                );

            routes.MapRoute(
                name: "UserCart",
                url: "Home/Cart/{productID}",
                defaults: new { controller = "Home", action = "UserCart", id = UrlParameter.Optional }
                );

            routes.MapRoute(
                name: "DemoteUser",
                url: "Account/Demote/{userId}",
                defaults: new { controller = "Account", action = "Demote", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "PromoteUser",
                url: "Account/Promote/{userId}",
                defaults: new { controller = "Account", action = "Promote", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "RemoveItem",
                url: "Editing/RemoveItem/{id}",
                defaults: new { controller = "Editing", action = "RemoveItem", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "Editing",
                url: "Editing/Edit/{id}",
                defaults: new { controller = "Editing", action = "Edit", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "Product",
                url: "Home/Product/{id}",
                defaults: new { controller = "Home", action = "Product", id = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
