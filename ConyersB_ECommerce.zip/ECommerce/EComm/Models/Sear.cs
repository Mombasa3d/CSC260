﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EComm.Models
{
    public class Search
    {
        public string Value { get; set; }
    }
}